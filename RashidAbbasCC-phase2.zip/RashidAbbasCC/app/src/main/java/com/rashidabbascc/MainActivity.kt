package com.rashidabbascc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.facebook.CallbackManager
import com.facebook.FacebookCallback
import com.facebook.FacebookException
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.rashidabbascc.ui.auth.AuthViewModel
import com.rashidabbascc.ui.nav.AppNavGraph
import com.rashidabbascc.ui.theme.RashidAbbasCCTheme

/**
 * Google and Facebook sign-in need an Activity (to launch the account picker / browser),
 * so those launchers live here and the AuthViewModel is shared with the nav graph.
 */
class MainActivity : ComponentActivity() {

    private lateinit var googleClient: GoogleSignInClient
    private val fbCallbackManager = CallbackManager.Factory.create()
    val authViewModel: AuthViewModel by viewModels()

    private val googleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            authViewModel.onGoogleSignIn(account)
        } catch (e: ApiException) {
            authViewModel.onGoogleSignIn(null)
        }
    }

    fun launchGoogleSignIn() {
        googleLauncher.launch(googleClient.signInIntent)
    }

    fun launchFacebookLogin() {
        LoginManager.getInstance().logInWithReadPermissions(this, listOf("email", "public_profile"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleClient = GoogleSignIn.getClient(this, gso)

        LoginManager.getInstance().registerCallback(fbCallbackManager, object : FacebookCallback<LoginResult> {
            override fun onSuccess(result: LoginResult) = authViewModel.onFacebookSignIn(result.accessToken)
            override fun onCancel() = authViewModel.onFacebookSignIn(null)
            override fun onError(error: FacebookException) = authViewModel.onFacebookSignIn(null)
        })

        setContent {
            RashidAbbasCCTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavGraph(activity = this)
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        fbCallbackManager.onActivityResult(requestCode, resultCode, data)
    }
}
