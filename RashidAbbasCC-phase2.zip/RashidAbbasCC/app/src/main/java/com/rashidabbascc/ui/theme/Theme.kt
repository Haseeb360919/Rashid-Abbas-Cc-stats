package com.rashidabbascc.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

val ClubGreen = Color(0xFF0B4F30)
val ClubGold = Color(0xFFC9A227)
val ClubGoldLight = Color(0xFFE6C766)

private val LightColors = lightColorScheme(
    primary = ClubGreen, onPrimary = Color.White,
    secondary = ClubGold, onSecondary = Color.Black,
    background = Color(0xFFF7F8F6), surface = Color.White,
    error = Color(0xFFB3261E)
)

private val DarkColors = darkColorScheme(
    primary = ClubGoldLight, onPrimary = Color.Black,
    secondary = ClubGreen, onSecondary = Color.White,
    background = Color(0xFF10130F), surface = Color(0xFF181C16),
    error = Color(0xFFF2B8B5)
)

@Composable
fun RashidAbbasCCTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val colors = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colors.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    MaterialTheme(colorScheme = colors, typography = Typography(), content = content)
}
