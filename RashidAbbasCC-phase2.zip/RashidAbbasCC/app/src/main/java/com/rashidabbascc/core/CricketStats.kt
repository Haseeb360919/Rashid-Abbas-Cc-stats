package com.rashidabbascc.core

/** Cricket overs are stored as legal balls. Never use decimal math for overs. */
object Overs {
    fun toBalls(overs: Int, extraBalls: Int): Int = overs * 6 + extraBalls
    fun display(legalBalls: Int): String = "${legalBalls / 6}.${legalBalls % 6}"
}

enum class Dismissal { NOT_OUT, BOWLED, CAUGHT, LBW, RUN_OUT, STUMPED, HIT_WICKET, RETIRED_HURT, RETIRED_OUT, OTHER }
enum class Verification { PENDING, VERIFIED, LOCKED }

data class Batting(
    val didBat: Boolean = false, val runs: Int = 0, val balls: Int = 0,
    val fours: Int = 0, val sixes: Int = 0, val dismissal: Dismissal = Dismissal.NOT_OUT
)

data class Bowling(
    val didBowl: Boolean = false, val legalBalls: Int = 0, val runsConceded: Int = 0,
    val wickets: Int = 0, val maidens: Int = 0, val wides: Int = 0, val noBalls: Int = 0,
    val byes: Int = 0, val legByes: Int = 0
)

data class Fielding(val catches: Int = 0, val runOuts: Int = 0, val stumpings: Int = 0)

data class Performance(
    val performanceId: String = "", val playerId: String = "", val seasonId: String = "",
    val matchId: String = "", val batting: Batting = Batting(), val bowling: Bowling = Bowling(),
    val fielding: Fielding = Fielding(), val status: Verification = Verification.PENDING
)

/** Returns a list of user-friendly errors; empty list = valid. */
fun validate(p: Performance): List<String> {
    val e = mutableListOf<String>()
    val b = p.batting; val w = p.bowling; val f = p.fielding
    if (b.didBat) {
        if (listOf(b.runs, b.balls, b.fours, b.sixes).any { it < 0 }) e += "Batting values cannot be negative."
        if (b.fours * 4 > b.runs) e += "Fours × 4 cannot exceed runs."
        if (b.sixes * 6 > b.runs) e += "Sixes × 6 cannot exceed runs."
        if (b.fours * 4 + b.sixes * 6 > b.runs) e += "Boundary runs cannot exceed total runs."
    }
    if (w.didBowl) {
        if (listOf(w.legalBalls, w.runsConceded, w.wickets, w.maidens, w.wides, w.noBalls, w.byes, w.legByes).any { it < 0 })
            e += "Bowling values cannot be negative."
        if (w.wickets > 10) e += "Wickets cannot exceed 10."
        if (w.maidens > w.legalBalls / 6) e += "Maidens cannot exceed completed overs."
    }
    if (listOf(f.catches, f.runOuts, f.stumpings).any { it < 0 }) e += "Fielding values cannot be negative."
    return e
}

/** Extra-ball input check for the "additional balls" field (0..5). */
fun validExtraBalls(x: Int) = x in 0..5

data class BattingTotals(
    val matches: Int, val innings: Int, val runs: Int, val balls: Int, val fours: Int, val sixes: Int,
    val notOuts: Int, val highScore: Int, val highScoreNotOut: Boolean,
    val thirties: Int, val fifties: Int, val hundreds: Int
) {
    val dismissals get() = innings - notOuts
    /** null => show "N/A" */
    val average: Double? get() = if (dismissals > 0) runs.toDouble() / dismissals else null
    val strikeRate: Double? get() = if (balls > 0) runs * 100.0 / balls else null
}

data class BowlingTotals(
    val matches: Int, val legalBalls: Int, val runsConceded: Int, val wickets: Int, val maidens: Int,
    val wides: Int, val noBalls: Int, val bestWickets: Int, val bestRuns: Int,
    val w2: Int, val w3: Int, val w4: Int, val w5: Int, val w6plus: Int
) {
    val overs get() = Overs.display(legalBalls)
    val economy: Double? get() = if (legalBalls > 0) runsConceded * 6.0 / legalBalls else null
    val average: Double? get() = if (wickets > 0) runsConceded.toDouble() / wickets else null
    val strikeRate: Double? get() = if (wickets > 0) legalBalls.toDouble() / wickets else null
    val best: String get() = if (matches == 0) "N/A" else "$bestWickets/$bestRuns"
}

fun battingTotals(list: List<Performance>): BattingTotals {
    val inns = list.filter { it.batting.didBat }
    val notOut = inns.count { it.batting.dismissal == Dismissal.NOT_OUT || it.batting.dismissal == Dismissal.RETIRED_HURT }
    val hs = inns.maxWithOrNull(compareBy({ it.batting.runs }, { it.batting.dismissal == Dismissal.NOT_OUT }))
    return BattingTotals(
        matches = list.size, innings = inns.size,
        runs = inns.sumOf { it.batting.runs }, balls = inns.sumOf { it.batting.balls },
        fours = inns.sumOf { it.batting.fours }, sixes = inns.sumOf { it.batting.sixes },
        notOuts = notOut, highScore = hs?.batting?.runs ?: 0,
        highScoreNotOut = hs?.batting?.dismissal == Dismissal.NOT_OUT,
        thirties = inns.count { it.batting.runs in 30..49 },
        fifties = inns.count { it.batting.runs in 50..99 },
        hundreds = inns.count { it.batting.runs >= 100 }
    )
}

fun bowlingTotals(list: List<Performance>): BowlingTotals {
    val spells = list.filter { it.bowling.didBowl }
    // Best bowling: most wickets, then fewest runs.
    val best = spells.minWithOrNull(compareBy({ -it.bowling.wickets }, { it.bowling.runsConceded }))
    return BowlingTotals(
        matches = spells.size, legalBalls = spells.sumOf { it.bowling.legalBalls },
        runsConceded = spells.sumOf { it.bowling.runsConceded }, wickets = spells.sumOf { it.bowling.wickets },
        maidens = spells.sumOf { it.bowling.maidens }, wides = spells.sumOf { it.bowling.wides },
        noBalls = spells.sumOf { it.bowling.noBalls },
        bestWickets = best?.bowling?.wickets ?: 0, bestRuns = best?.bowling?.runsConceded ?: 0,
        w2 = spells.count { it.bowling.wickets == 2 }, w3 = spells.count { it.bowling.wickets == 3 },
        w4 = spells.count { it.bowling.wickets == 4 }, w5 = spells.count { it.bowling.wickets == 5 },
        w6plus = spells.count { it.bowling.wickets >= 6 }
    )
}

fun fmt(v: Double?, digits: Int = 2): String =
    if (v == null || v.isNaN() || v.isInfinite()) "N/A" else "%.${digits}f".format(v)

/** Team/leaderboard stats should count only VERIFIED or LOCKED records (see README). */
fun countable(list: List<Performance>) = list.filter { it.status != Verification.PENDING }
