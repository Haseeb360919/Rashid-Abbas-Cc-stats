package com.rashidabbascc.data

import com.facebook.AccessToken
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.firebase.auth.FacebookAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

enum class PlayingRole { BATSMAN, BOWLER, ALL_ROUNDER, WICKETKEEPER }

data class PlayerProfile(
    val playerId: String = "",
    val fullName: String = "",
    val email: String = "",
    val jerseyNumber: Int = 0,
    val playingRole: String = PlayingRole.BATSMAN.name,
    val battingStyle: String = "",
    val bowlingStyle: String = "",
    val photoUrl: String = "",
    val role: String = "player", // "player" or "admin"
    val active: Boolean = true,
    val joinDate: Long = System.currentTimeMillis()
)

/** Friendly text for common Firebase auth failures. */
fun friendlyAuthError(t: Throwable): String {
    val msg = t.message ?: ""
    return when {
        "email address is already in use" in msg -> "This email is already registered. Try logging in instead."
        "password is invalid" in msg || "no user record" in msg -> "Wrong email or password."
        "badly formatted" in msg -> "Please enter a valid email address."
        "network error" in msg.lowercase() -> "No internet connection. Please check your network and try again."
        "weak password" in msg.lowercase() -> "Password should be at least 6 characters."
        else -> "Something went wrong. Please try again."
    }
}

class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    val currentUserId: String? get() = auth.currentUser?.uid

    suspend fun signUpWithEmail(
        fullName: String, email: String, password: String,
        jerseyNumber: Int, role: PlayingRole
    ): Result<Unit> = runCatching {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        val uid = result.user?.uid ?: error("Sign up failed. Please try again.")
        val profile = PlayerProfile(
            playerId = uid, fullName = fullName, email = email,
            jerseyNumber = jerseyNumber, playingRole = role.name
        )
        db.collection("players").document(uid).set(profile).await()
        db.collection("users").document(uid)
            .set(mapOf("role" to "player", "email" to email), SetOptions.merge()).await()
    }

    suspend fun loginWithEmail(email: String, password: String): Result<Unit> = runCatching {
        auth.signInWithEmailAndPassword(email, password).await()
        Unit
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> = runCatching {
        auth.sendPasswordResetEmail(email).await()
    }

    suspend fun signInWithGoogle(account: GoogleSignInAccount): Result<Unit> = runCatching {
        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        val result = auth.signInWithCredential(credential).await()
        ensurePlayerDoc(result.user?.uid, result.user?.displayName, result.user?.email)
    }

    suspend fun signInWithFacebook(token: AccessToken): Result<Unit> = runCatching {
        val credential = FacebookAuthProvider.getCredential(token.token)
        val result = auth.signInWithCredential(credential).await()
        ensurePlayerDoc(result.user?.uid, result.user?.displayName, result.user?.email)
    }

    private suspend fun ensurePlayerDoc(uid: String?, name: String?, email: String?) {
        if (uid == null) return
        val doc = db.collection("players").document(uid).get().await()
        if (!doc.exists()) {
            db.collection("players").document(uid)
                .set(PlayerProfile(playerId = uid, fullName = name ?: "", email = email ?: "")).await()
            db.collection("users").document(uid)
                .set(mapOf("role" to "player", "email" to (email ?: "")), SetOptions.merge()).await()
        }
    }

    fun logout() = auth.signOut()

    suspend fun deleteAccount(): Result<Unit> = runCatching {
        auth.currentUser?.delete()?.await()
        Unit
    }
}
