package com.rashidabbascc.ui.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Placeholder dashboard — Phase 3 replaces this with live stats,
 * "+ ADD MY MATCH", and bottom navigation (Home / Matches / Stats / Leaderboard / Profile).
 */
@Composable
fun HomeScreen(onLogout: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("RASHID ABBAS CC") }) }) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("You're logged in!", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Dashboard, Add Match, and Stats screens arrive in Phase 3.",
                style = MaterialTheme.typography.bodyMedium, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            OutlinedButton(onClick = onLogout) { Text("Logout") }
        }
    }
}
