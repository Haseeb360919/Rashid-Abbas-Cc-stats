package com.rashidabbascc.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rashidabbascc.data.AuthRepository
import com.rashidabbascc.data.PlayingRole
import com.rashidabbascc.data.friendlyAuthError
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.facebook.AccessToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AuthUiState {
    data object Idle : AuthUiState()
    data object Loading : AuthUiState()
    data object Success : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthViewModel(private val repo: AuthRepository = AuthRepository()) : ViewModel() {

    private val _state = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val state: StateFlow<AuthUiState> = _state.asStateFlow()

    val isLoggedIn: Boolean get() = repo.currentUserId != null

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _state.value = AuthUiState.Error("Please enter your email and password.")
            return
        }
        _state.value = AuthUiState.Loading
        viewModelScope.launch {
            repo.loginWithEmail(email.trim(), password)
                .onSuccess { _state.value = AuthUiState.Success }
                .onFailure { _state.value = AuthUiState.Error(friendlyAuthError(it)) }
        }
    }

    fun signUp(
        fullName: String, email: String, password: String, confirmPassword: String,
        jerseyNumber: String, role: PlayingRole
    ) {
        if (fullName.isBlank() || email.isBlank() || password.isBlank()) {
            _state.value = AuthUiState.Error("Please fill in all required fields.")
            return
        }
        if (password != confirmPassword) {
            _state.value = AuthUiState.Error("Passwords do not match.")
            return
        }
        if (password.length < 6) {
            _state.value = AuthUiState.Error("Password should be at least 6 characters.")
            return
        }
        val jersey = jerseyNumber.toIntOrNull() ?: 0
        _state.value = AuthUiState.Loading
        viewModelScope.launch {
            repo.signUpWithEmail(fullName.trim(), email.trim(), password, jersey, role)
                .onSuccess { _state.value = AuthUiState.Success }
                .onFailure { _state.value = AuthUiState.Error(friendlyAuthError(it)) }
        }
    }

    fun forgotPassword(email: String) {
        if (email.isBlank()) {
            _state.value = AuthUiState.Error("Enter your email first, then tap 'Forgot Password'.")
            return
        }
        viewModelScope.launch {
            repo.sendPasswordReset(email.trim())
                .onSuccess { _state.value = AuthUiState.Error("Password reset email sent. Check your inbox.") }
                .onFailure { _state.value = AuthUiState.Error(friendlyAuthError(it)) }
        }
    }

    fun onGoogleSignIn(account: GoogleSignInAccount?) {
        if (account == null) {
            _state.value = AuthUiState.Error("Google sign-in was cancelled.")
            return
        }
        _state.value = AuthUiState.Loading
        viewModelScope.launch {
            repo.signInWithGoogle(account)
                .onSuccess { _state.value = AuthUiState.Success }
                .onFailure { _state.value = AuthUiState.Error(friendlyAuthError(it)) }
        }
    }

    fun onFacebookSignIn(token: AccessToken?) {
        if (token == null) {
            _state.value = AuthUiState.Error("Facebook login was cancelled.")
            return
        }
        _state.value = AuthUiState.Loading
        viewModelScope.launch {
            repo.signInWithFacebook(token)
                .onSuccess { _state.value = AuthUiState.Success }
                .onFailure { _state.value = AuthUiState.Error(friendlyAuthError(it)) }
        }
    }

    fun resetState() { _state.value = AuthUiState.Idle }
}
