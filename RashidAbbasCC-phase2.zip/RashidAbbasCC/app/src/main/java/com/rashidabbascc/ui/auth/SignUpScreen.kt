package com.rashidabbascc.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.rashidabbascc.data.PlayingRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignUpScreen(
    vm: AuthViewModel = viewModel(),
    onSignedUp: () -> Unit,
    onGoToLogin: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var jersey by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(PlayingRole.BATSMAN) }
    var roleMenuOpen by remember { mutableStateOf(false) }
    val state by vm.state.collectAsState()

    LaunchedEffect(state) {
        if (state is AuthUiState.Success) onSignedUp()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Create Account") }) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            Text("Join Rashid Abbas CC", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))

            OutlinedTextField(fullName, { fullName = it }, label = { Text("Full Name") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(password, { password = it }, label = { Text("Password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(confirmPassword, { confirmPassword = it }, label = { Text("Confirm Password") },
                singleLine = true, visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(jersey, { jersey = it.filter { c -> c.isDigit() } }, label = { Text("Jersey Number") },
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))

            ExposedDropdownMenuBox(expanded = roleMenuOpen, onExpandedChange = { roleMenuOpen = it }) {
                OutlinedTextField(
                    value = role.name.replace("_", "-").lowercase().replaceFirstChar { it.uppercase() },
                    onValueChange = {}, readOnly = true, label = { Text("Playing Role") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = roleMenuOpen) },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = roleMenuOpen, onDismissRequest = { roleMenuOpen = false }) {
                    PlayingRole.values().forEach { r ->
                        DropdownMenuItem(
                            text = { Text(r.name.replace("_", "-").lowercase().replaceFirstChar { it.uppercase() }) },
                            onClick = { role = r; roleMenuOpen = false }
                        )
                    }
                }
            }

            if (state is AuthUiState.Error) {
                Spacer(Modifier.height(8.dp))
                Text((state as AuthUiState.Error).message, color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { vm.signUp(fullName, email, password, confirmPassword, jersey, role) },
                enabled = state !is AuthUiState.Loading,
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                if (state is AuthUiState.Loading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else Text("Create Account")
            }
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onGoToLogin, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Already have an account? Login")
            }
        }
    }
}
