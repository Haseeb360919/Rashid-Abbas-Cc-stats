package com.rashidabbascc.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rashidabbascc.MainActivity
import com.rashidabbascc.ui.auth.LoginScreen
import com.rashidabbascc.ui.auth.SignUpScreen
import com.rashidabbascc.ui.home.HomeScreen
import com.google.firebase.auth.FirebaseAuth

object Routes {
    const val LOGIN = "login"
    const val SIGNUP = "signup"
    const val HOME = "home"
}

@Composable
fun AppNavGraph(
    activity: MainActivity,
    navController: NavHostController = rememberNavController()
) {
    val startDestination = if (FirebaseAuth.getInstance().currentUser != null) Routes.HOME else Routes.LOGIN

    NavHost(navController = navController, startDestination = startDestination) {
        composable(Routes.LOGIN) {
            LoginScreen(
                vm = activity.authViewModel,
                onLoggedIn = { navController.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } } },
                onGoToSignUp = { navController.navigate(Routes.SIGNUP) },
                onGoogleClick = { activity.launchGoogleSignIn() },
                onFacebookClick = { activity.launchFacebookLogin() }
            )
        }
        composable(Routes.SIGNUP) {
            SignUpScreen(
                vm = activity.authViewModel,
                onSignedUp = { navController.navigate(Routes.HOME) { popUpTo(Routes.LOGIN) { inclusive = true } } },
                onGoToLogin = { navController.popBackStack() }
            )
        }
        composable(Routes.HOME) {
            HomeScreen(onLogout = {
                FirebaseAuth.getInstance().signOut()
                navController.navigate(Routes.LOGIN) { popUpTo(Routes.HOME) { inclusive = true } }
            })
        }
    }
}
