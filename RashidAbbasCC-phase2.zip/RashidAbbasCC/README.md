# RASHID ABBAS CC — Phase 1 (core + security)

Included: cricket math engine (overs-as-balls, batting/bowling totals, validation), Firestore rules.
NOT yet included: Gradle setup, Compose UI, navigation, Auth/Firestore repositories, charts, export.

## Firebase setup (needed for later phases)
1. console.firebase.google.com → create project → add Android app (package `com.rashidabbascc`).
2. Add SHA-1 and SHA-256: `./gradlew signingReport` (Android Studio terminal).
3. Download `google-services.json` → put in `app/` (never commit it publicly).
4. Authentication → enable Email/Password, Google, Facebook.
5. Facebook: developers.facebook.com → create app → copy App ID + Client Token into
   `res/values/secrets.xml` (git-ignored) → paste App ID & App Secret in Firebase's Facebook provider,
   and add Firebase's OAuth redirect URI in Facebook Login settings.
6. Firestore → create database → Rules tab → paste `firestore.rules` → Publish.
7. First admin: sign up, then in Firestore set `users/{your uid}.role = "admin"` manually.

## Design decision for you
Team stats/leaderboards: count only VERIFIED/LOCKED records (`countable()`), or include PENDING too?

## Phase 2 — what's now included
- Full Gradle project (Kotlin + Compose + Material 3 + Firebase BoM + Google Sign-In + Facebook Login).
- Screens: Login, Sign Up (with Jersey Number + Playing Role), placeholder Home/Dashboard.
- `AuthRepository`: email sign-up/login, Google, Facebook, forgot password, logout, delete account.
  Creates a `players/{uid}` profile doc + `users/{uid}` role doc on first sign-in — passwords are
  never stored in Firestore (Firebase Auth handles them).
- Friendly error messages for wrong password, duplicate email, no network, etc.
- Offline-first Firestore cache enabled in `RashidAbbasApp.kt`.

## Build it in GitHub Codespaces (from your phone browser, Desktop-site mode)
1. On github.com, create a new **empty** repository, e.g. `RashidAbbasCC`.
2. Open it → **Code** → **Codespaces** tab → **Create codespace on main**.
3. In the file explorer (left sidebar), use the "..." menu → **Upload...** and upload this zip file.
4. In the terminal at the bottom, run:
   ```
   unzip RashidAbbasCC-phase2.zip -d .
   rm RashidAbbasCC-phase2.zip
   ```
5. Gradle wrapper isn't included (binary files aren't safely hand-written). Install Gradle once and generate it:
   ```
   sudo apt-get update && sudo apt-get install -y gradle
   gradle wrapper --gradle-version 8.7
   ```
6. **Before building**, do the Firebase & Facebook setup below — the app won't compile Google/Facebook
   login correctly without real IDs in `app/src/main/res/values/strings.xml` and `google-services.json`.
7. Build the APK:
   ```
   ./gradlew assembleDebug
   ```
8. Find it at `app/build/outputs/apk/debug/app-debug.apk` → right-click → **Download** → install on your phone
   (you'll need to allow "install from unknown sources" once).

## Firebase & OAuth setup (required before the APK will actually log in)
1. console.firebase.google.com → create project → **Add app → Android** → package name `com.rashidabbascc`.
2. Get SHA-1/SHA-256: in Codespaces terminal, `keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android` (Android Studio's default debug keystore; Codespaces may need `keytool -genkey` first time — ask me if it's missing).
3. Download `google-services.json` from Firebase → upload it into the `app/` folder in Codespaces.
4. Firebase Console → Authentication → Sign-in method → enable **Email/Password** and **Google**.
   Copy the **Web client ID** shown under Google → paste into `strings.xml` → `default_web_client_id`.
5. developers.facebook.com → create app → Facebook Login product → copy **App ID** and **Client Token**
   → paste into `strings.xml` (`facebook_app_id`, `fb_login_protocol_scheme` becomes `fb<APP_ID>`, `facebook_client_token`).
   In Firebase → Authentication → Sign-in method → Facebook, paste the App ID + App Secret, then copy
   Firebase's OAuth redirect URI into Facebook's Login settings → Valid OAuth Redirect URIs.
6. Firestore Database → create (production mode) → Rules tab → paste `firestore.rules` from this repo → Publish.
7. First admin: sign up once in the app, then in Firestore manually set `users/{that uid}.role` to `"admin"`.

## Known placeholders / next phase
- Home screen is a placeholder ("You're logged in!") — Phase 3 builds the real dashboard,
  + ADD MY MATCH, batting/bowling/fielding forms, My Matches, Team Stats, Leaderboards, charts.
- Admin panel, seasons, awards, and PDF/CSV export are Phase 4.
